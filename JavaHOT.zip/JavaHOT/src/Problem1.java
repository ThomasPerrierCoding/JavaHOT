import javax.swing.JOptionPane;
import java.text.DecimalFormat;

public class Problem1 {
    // Constants
    private static final double CMINANINCH = 2.54;

    //  Variables
    static String invalidInput = "Invalid Input! Input Must Be A Number";
    static String inputStr = "";
    static String outputStr = "";
    static double centimeters = 0;
    static int inches = 0;

    public static void main(String[] args) {
        boolean inputAccepted = false;
        while(!inputAccepted) { //Validates user input to make sure it is an integer
            try {
                inches = Integer.parseInt(JOptionPane.showInputDialog("Input Number Of Inches To Convert"));
                    inputAccepted = true;
                } catch(NumberFormatException e) {
                JOptionPane.showMessageDialog(null,invalidInput);
            }
        }
        centimeters = inches * CMINANINCH;  //Gets the total number of centimeters in an inch
        outputStr = "Number of Centimeters in "+inches+" inches: "+centimeters;

        JOptionPane.showMessageDialog(null,outputStr);  //Displays to the user the end result
    }
}
