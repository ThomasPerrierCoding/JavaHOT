import javax.swing.JOptionPane;
import java.text.DecimalFormat;

public class Problem3 {
    //  Constants
    private static String INVALIDINPUT = "Invalid Input! Input Must Be A Number";

    //  Variables
    static String inputStr = "";
    static String outputStr = "";
    static int n = 0;

    public static void main(String[] args) {
        boolean inputAccepted = false;
        while(!inputAccepted) { //Validates user input to make sure it is an integer
            try {
                n = Integer.parseInt(JOptionPane.showInputDialog("Input A Number"));
                inputAccepted = true;
            } catch(NumberFormatException e) {
                JOptionPane.showMessageDialog(null,INVALIDINPUT);
            }
        }
        for (int i = 1; i <= n; i++) { // Runs through the loop checking if i is a multiple of 3, 5, or 3 and 5
            if (i % 3 == 0 && i % 5 == 0) { // Prints FizzBuzz because number is a multiple of 3 and 5
                outputStr+="FizzBuzz\n";
            }
            else if (i % 5 == 0) {// Prints Buzz because number is a multiple of 5
                outputStr+="Buzz\n";
            }
            else if (i % 3 == 0) {// Prints Fizz because number is a multiple of 3
                outputStr+="Fizz\n";
            }
            else{// Prints number because it is not a multiple of 3 or 5
                outputStr+= i+"\n";
            }
        }
        JOptionPane.showMessageDialog(null,outputStr);   //Displays to the user the end result
    }
}
