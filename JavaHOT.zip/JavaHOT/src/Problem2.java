import javax.swing.JOptionPane;
import java.text.DecimalFormat;

public class Problem2 {
    //  Constants
    private static final int LCV = 100;

    //  Variables
    static  int sumOfPerfectSquares = 0;
    static String outputStr = "";

    public static void main(String[] args) {
        for(int i = 0;i<=LCV;i++){  //Runs through the loop adding up all of the squares
            sumOfPerfectSquares+= Math.pow(i,2);
        }
        outputStr = "The sum of the first 100 perfect squares is: "+sumOfPerfectSquares;
        JOptionPane.showMessageDialog(null,outputStr);  //Displays to the user the end result
    }
}
