import javax.swing.JOptionPane;
import java.text.DecimalFormat;

public class Problem5 {
    // Constants
    private static final int ECV = 0;
    private static final double TAX = 0.8;
    private static String INVALIDINPUT = "Invalid Input! Input Must Be A Number";

    //  Variables
    private static DecimalFormat pattern1 = new DecimalFormat("$###,###,##0.00");
    static double price = 0.0;
    static double subTotal = 0.0;
    static double taxTotal = 0.0;
    static  double total = 0.0;
    static int lcv = 0;
    static String inputStr = "";
    static String outputStr = "";


    public static void main(String[] args) {
        boolean inputAccepted = false;
        while(!inputAccepted) { //Validates user input to make sure it is an integer
            try {
                lcv = Integer.parseInt(JOptionPane.showInputDialog("Input Number Of Prices To Enter"));
                inputAccepted = true;
            } catch(NumberFormatException e) {
                JOptionPane.showMessageDialog(null,INVALIDINPUT);
            }
        }
        for(int i=1;i<=lcv;i++)
        {
            boolean input2Accepted = false;
            while(!input2Accepted) { //Validates user input to make sure it is an integer
                try {
                    price = Double.parseDouble(JOptionPane.showInputDialog("Input Price Or Input 0 To Print Results"));
                    if(price==0)
                    {
                        i=lcv;
                        input2Accepted = true;
                    }
                    else{
                        input2Accepted = true;
                        subTotal+=price;
                    }
                } catch(NumberFormatException e) {
                    JOptionPane.showMessageDialog(null,INVALIDINPUT);
                }
            }
        }

        taxTotal = subTotal*TAX;
        total = subTotal  +taxTotal;

        outputStr+="SubTotal: "+pattern1.format(subTotal);
        outputStr+="\nTax(8%): "+pattern1.format((subTotal*TAX));
        outputStr+="\nTotal: "+pattern1.format(total);

        JOptionPane.showMessageDialog(null,outputStr);
    }
}
